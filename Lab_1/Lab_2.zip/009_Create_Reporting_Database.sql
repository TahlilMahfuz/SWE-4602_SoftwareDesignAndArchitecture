drop database kids_shop_reporting_DB;
create database kids_shop_reporting_DB;