use kids_shop_reporting_db;

#  get_top_employee_by_duration(start_date: DATE, end_date: DATE)
DELIMITER //
CREATE PROCEDURE get_top_employee_by_duration(IN start_date DATE, IN end_date DATE)
BEGIN
    select *
        from fact_sale,dimension_employee
        where fact_sale.employee_id = dimension_employee.employee_id
        and fact_sale.sale_date between start_date and end_date
        order by fact_sale.sale_amount desc limit 1;
END //
DELIMITER ;

call get_top_employee_by_duration('2020-01-01', '2020-12-31');