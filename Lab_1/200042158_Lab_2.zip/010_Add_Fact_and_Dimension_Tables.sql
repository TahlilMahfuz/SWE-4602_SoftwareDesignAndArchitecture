use kids_shop;

create table kids_shop_reporting_db.dimension_product
as select * from kids_shop.product;

create table kids_shop_reporting_db.dimension_categories
as select * from kids_shop.category;

create table kids_shop_reporting_db.dimension_customer
as select * from kids_shop.customer;

create table kids_shop_reporting_db.dimension_employee
as select * from kids_shop.employee;

create table kids_shop_reporting_db.dimension_invoice
as select * from kids_shop.invoice;

create table kids_shop_reporting_db.dimension_rating
as select * from kids_shop.rating;

alter table rating add  int default 0;

drop table kids_shop_reporting_db.fact_sale;

create table kids_shop_reporting_db.fact_sale (
    sale_id int,
    product_id int,
    category_id int,
    customer_id int,
    employee_id int,
    invoice_id int,
    sale_date date,
    rating_id int,
    sale_amount decimal(10,2)
);