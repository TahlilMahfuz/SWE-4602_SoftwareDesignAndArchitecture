DELIMITER //
CREATE PROCEDURE get_sale_per_category(IN employee_id INT)
BEGIN
    SELECT c.id AS category_id,
           c.name AS category_name,
           SUM(s.quantity * s.unit_price) AS total_sale
    FROM sale s
    JOIN invoice i ON s.invoice_id = i.invoice_id
    JOIN category c ON s.category_id = c.id
    WHERE i.employee_id = employee_id
    GROUP BY c.id, c.name;
END //
DELIMITER ;