alter table category add column total_sale double not null default 0;
alter table sale add column category_id int not null references category(id);